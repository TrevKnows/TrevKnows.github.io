//  Created by Trevor Beaton on 12/14/17.
//  Copyright © 2018 Adafruit Industries All rights reserved.

import UIKit
import Foundation
import PlaygroundSupport
import PlaygroundBluetooth


let rcViewController: RCViewController = RCViewController(1)
PlaygroundPage.current.liveView = rcViewController



import UIKit
import PlaygroundSupport

public class ContainerLiveView: UIView, PlaygroundLiveViewSafeAreaContainer {}
